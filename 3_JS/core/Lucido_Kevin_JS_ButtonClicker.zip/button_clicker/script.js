function logOut(element) {
    element.innerText = "Logout";
}

function remove(element) {
    element.remove();
}